# Smart Chicken
## PEC 2018-2019 Q1

> By Pau Serra & David Soldevila
